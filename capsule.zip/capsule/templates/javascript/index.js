document.getElementById('date').innerHTML = new Date().toDateString();

var g = document.getElementById("graph");
var graph2d = g.getContext("2d");

const Http = new XMLHttpRequest();
const url= 'http://127.0.0.1:5000/gimmegimme?u=x%2By&px1=1&px2=4&py=2&m=36';
Http.open("PUSH",url);
Http.send();

Http.onreadystatechange=(e)=>{console.log(Http.resposneText)}
