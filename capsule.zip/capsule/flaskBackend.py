import traceback
from logging import *
from flask import *
from flask_socketio import SocketIO
import micrographer2

app = Flask(__name__)
socketio = SocketIO(app)
app.config['SECRET_KEY'] = 'jsdhjshjk837944789378923798$*(&#*&(#'

@app.route('/')
def session():
    return render_template('index.html')

def myCallback():
    print('client: acknowledged response')

@socketio.on('genGraphs')
def event_handler(json, methods=['GET', 'POST']):
    print("json: "+str(json))
    print('server: received request, responding...')
    if ('u' in json.keys()):
        json_r = None
        try:
            json_r = micrographer2.run(json['u'],json['px_1'],json['px_2'],\
                             json['py'],json['m'],json['width'],json['height'])
        except Exception as e:
            error(traceback.format_exc())
            #json = None
            
        if json_r is None:
            json_r = {'error':-1}
        elif json_r == 1:
            json_r = {'error':1}
            
        socketio.emit('displayGraphs', json_r, callback=myCallback)
        



if __name__=="__main__":
    socketio.run(app)
