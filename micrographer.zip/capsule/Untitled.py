def f(n):
    while n:
        if (n%10)%3!=0:
            return False
        n=n//pow(10,3)
    return True
